package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Login;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;


@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet {
	LoginService logSer=null;
	private static final long serialVersionUID = 1L;
       
    
    public ValidateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		logSer=new LoginServiceImpl();
		String unm=request.getParameter("uname");
		String pass=request.getParameter("pass");
		try
		{
			Login usr=logSer.getUserByUnm(unm);
			if((usr.getUserName().equalsIgnoreCase(unm))&&(usr.getPassword().equalsIgnoreCase(pass)))
			{
				//pw.print("Welcome :"+ unm+"U R valid User");
				RequestDispatcher rdSuccess=request.getRequestDispatcher("/SuccessServlet");
				rdSuccess.forward(request, response);
			}
			else
			{
				//pw.print("Sorry u r invalid user");
				RequestDispatcher rdFailure=request.getRequestDispatcher("/HTMLFiles/login1.html");
				rdFailure.forward(request, response);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
