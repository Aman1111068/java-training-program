package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.LoginDao;
import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;

public class LoginServiceImpl implements LoginService
{
	LoginDao logDao=null;
	

	public LoginServiceImpl() {
		super();
		logDao= new LoginDaoImpl();
		// TODO Auto-generated constructor stub
	}


	@Override
	public Login getUserByUnm(String unm) throws SQLException {
		// TODO Auto-generated method stub
		
		return logDao.getUserByUnm(unm);
	}
	

}
