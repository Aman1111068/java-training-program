import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.InsuranceService;


public class TestHashMap {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int eId;
		String eName;
		double eSalary;
		String eDesignation;

		System.out.println("Enter No of Employees:");
		int count=sc.nextInt();
		Employee emp[]=new Employee[count];
		HashMap<Integer,Employee> hmap = new HashMap<Integer,Employee>();
		for(int i=1;i<=count;i++)
		{
			System.out.println("Enter Employee Id:");
			eId=sc.nextInt();
			System.out.println("Enter Employee Name:");
			eName=sc.next();
			System.out.println("Enter Employee Salary: ");
			eSalary=sc.nextDouble();
			System.out.println("Enter Employee Designation:");
			eDesignation=sc.next();
			InsuranceService ser = new InsuranceService(eSalary,eDesignation);
			String isc=ser.getInsuranceScheme();
			emp[i]=new Employee(eId,eName,eSalary,eDesignation,isc);
			hmap.put(i, emp[i]);
		}
		System.out.println("Enter Insurance Scheme:");
		
		hmap
		

	}

}
