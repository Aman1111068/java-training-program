
public class Account {

    private long accNumber;
    private double balance ;
    Person accHolder;
    
    public Account() {
        
    }

    public Account(Person accHolder, long accNumber,
            double balance) 
    {
    
        this.accNumber = accNumber;
        this.balance = balance;
        this.accHolder = accHolder;
    }

    public long getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(long accNumber) {
        this.accNumber = accNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    public void deposit(double amount){
        this.balance = this.balance + amount;
    }
    public void withdraw(double amount){
        
        this.balance = this.balance - amount;
        
    }

    @Override
    public String toString() {
        return " [accNumber=" + accNumber + ", accHolder="
                + accHolder.toString() + "]";
    }
}
