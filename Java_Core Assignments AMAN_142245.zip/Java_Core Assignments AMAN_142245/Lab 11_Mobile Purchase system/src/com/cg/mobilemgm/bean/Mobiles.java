package com.cg.mobilemgm.bean;

public class Mobiles {
	private int mobileId;
	private String mobileName;
	private float mobilePrice;
	private int mobileQuantity;
	public int getMobileId() {
		return mobileId;
	}
	public int setMobileId(int mobileId) {
		return this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public float getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(float mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public int getMobileQuantity() {
		return mobileQuantity;
	}
	public void setMobileQuantity(int mobileQuantity) {
		this.mobileQuantity = mobileQuantity;
	}
	public Mobiles() {
		super();
		
	}
	public Mobiles(int mobileId, String mobileName, float mobilePrice,
			int mobileQuantity) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.mobileQuantity = mobileQuantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", mobileName=" + mobileName
				+ ", mobilePrice=" + mobilePrice + ", mobileQuantity="
				+ mobileQuantity + "]";
	}
	

}
