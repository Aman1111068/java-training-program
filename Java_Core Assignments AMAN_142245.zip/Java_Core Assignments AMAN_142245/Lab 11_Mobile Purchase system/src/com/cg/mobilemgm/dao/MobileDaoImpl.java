package com.cg.mobilemgm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;
import com.cg.mobilemgm.util.DBUtil;


public class MobileDaoImpl implements MobileDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger mobLogger=null;

	public MobileDaoImpl()
	{
		PropertyConfigurator.configure("resourses/log4j.properties");
		mobLogger=Logger.getLogger("MobileDaoImpl.class");
	}
	@Override
	public int addMobPur(PurchaseDetails pur,Mobiles mob) throws MobileException {
		int dataAdded;
		long millis=System.currentTimeMillis();  
		java.sql.Date purDatee=new java.sql.Date(millis);
		String insertQry="INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(?, ?, ?, ?, ?, ?)";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setLong(1, getPurchaseId());
			pst.setString(2, pur.getCustName());
			pst.setString(3,pur.getCustEmail());
			pst.setString(4,pur.getCustPhoneNo());
			pst.setDate(5, purDatee);
			pst.setInt(6, mob.getMobileId());
			dataAdded=pst.executeUpdate();
			mobLogger.log(Level.INFO, "Purchase Detail Inserted");
			/*dataAdded=1 after execution 
			 * bcoz it depends on number of records adding
			 * and that result in case of insert query is 1
			 */
		} 
		catch (Exception e) 
		{
			//mobLogger.error("This is Exception:"+e.getMessage());
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());	
			}
		}
		return dataAdded;
	}
	/////////////////
	public long getPurchaseId() throws MobileException
	{
		int generatedVal;
		String qry="SELECT mob_seq.NEXTVAL "
				+ " FROM DUAL";
		try 
		{
			con=DBUtil.getCon();
			System.out.println(con);
			st=con.createStatement();
			rs=st.executeQuery(qry);

			rs.next();

			generatedVal=rs.getInt(1);

		} 
		catch (Exception e) 
		{

			throw new MobileException(e.getMessage());		
		} 
		finally//reqd to closing all connections which are opened like con
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{	
				throw new MobileException(e.getMessage());		
			}

		}
		return generatedVal;
	}
	/**************************************************************************/




	/****************************************************************************/

	@Override
	public ArrayList<Integer> getAllMobileId() throws MobileException 
	{
		ArrayList<Integer> mobList= new ArrayList<Integer>();
		String selectQry="SELECT mobileid FROM mobiles" ;

		try{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{

				int mm=rs.getInt("mobileid");
				mobList.add(mm);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}
	////////////////////////////////////////////////
	@Override
	public int getMobQuan(Mobiles mob) throws MobileException
	{
		String qry="SELECT quantity FROM mobiles WHERE mobileid=?";
		int data=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setInt(1, mob.getMobileId());
			rs=pst.executeQuery();
			rs.next();
			data=rs.getInt(1);
			mobLogger.log(Level.INFO, "Purchase Detail Inserted"+mob);
			System.out.println(data);
		}
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				con.close();
				pst.close();
				rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return data;
	}
	////////////////////////////////
	@Override
	public ArrayList<Mobiles> getAllMob() throws MobileException {
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String selectQry = "SELECT * FROM mobiles";
		Mobiles m = null;
		try 
		{
			con=DBUtil.getCon();
			st= con.createStatement();
			rs= st.executeQuery(selectQry);
			while(rs.next())
			{
				m = new Mobiles(rs.getInt("mobileid"),
						rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(m);
				mobLogger.log(Level.INFO, "Mobile Detail:  "+m);
			}
		} 
		catch (Exception e) 
		{
			mobLogger.error("This is Exception:"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}
	////////////////////////////////deletedetailofmobile/////////////////////////////////////////////
	@Override
	public int deleteMobDetail(int mobId)throws MobileException
	{
		int dataDeleted;
		String delQuery=" DELETE FROM Mobiles WHERE mobileid=?";
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(delQuery);
			pst.setInt(1, mobId);
			dataDeleted=pst.executeUpdate();
			
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{

				pst.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;
	}

	/////////////////////////////////////
	public ArrayList<Mobiles> searchMob(float maxRange, float minRange) 
			throws MobileException
			{
		//int datasearch;
		Mobiles mob=null;
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String searchQuery="SELECT * FROM mobiles WHERE price BETWEEN ? AND ?";
		try{
			con=DBUtil.getCon();
			pst=con.prepareStatement(searchQuery);
			pst.setFloat(1, minRange);
			pst.setFloat(2, maxRange);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mob = new Mobiles(rs.getInt("mobileid"),
						rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mob);
			}

		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{

				pst.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;

			}
	///////////////////////
	@Override
	public int updateMobile(Mobiles mob) throws MobileException
	{
		int dataupdated;
		String updateQuery="UPDATE mobiles SET quantity= (quantity - ?) WHERE mobileid=? ";
		try{	
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQuery);
			pst.setInt(1, mob.getMobileQuantity());
			pst.setInt(2, mob.getMobileId());
			dataupdated=pst.executeUpdate();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{

				pst.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		return dataupdated;

	}


}
