package com.cg.mobilemgm.service;
import java.util.ArrayList;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;

public interface MobileService 
{
	public int addMobPur(PurchaseDetails pur,Mobiles mob) throws MobileException;
	public long generateMobId() throws MobileException;
	public boolean validateDigit(String phnNo) throws MobileException;
	public boolean validateEmail(String email) throws MobileException;
	public boolean validateName(String cusName) throws MobileException;
	public boolean validateMobileId(int mobId) throws MobileException;
	public int validateMobileQuan(Mobiles mob) throws MobileException;
	
	public ArrayList<Mobiles> getAllMob() throws MobileException;
	public int deleteMobDetail(int mobId)throws MobileException;
	public ArrayList<Mobiles> searchMob(float maxRange, float minRange) 
			throws MobileException;
	
	public int updateMobile(Mobiles mob) throws MobileException;

}
