
public class Account {
	private long accNum;
	private double balance;
	Person accHolder;
	
	public Account() {		
	}
	public Account(long accNum, double balance, Person accHolder) {
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder=accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void withdraw(double amount)
	{
		if((this.balance-amount)<500){
		}
		else{
			this.balance=balance-amount;
		}
	}
	
	public void deposit(double amount)
	{
		this.balance=balance+amount;
	}

	public String toString() {
		return "accNum=" + accNum + ", Current balance=" + balance
				+ ", accHolder=" + accHolder.toString();
	}
	
}
	
	

