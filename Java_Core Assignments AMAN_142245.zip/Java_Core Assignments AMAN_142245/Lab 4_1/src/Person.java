
public class Person {

	private String perName;
	private float perAge;
	public Person() {
		
	}
	public Person(String perName, float perAge) {
		this.perName = perName;
		this.perAge = perAge;
	}
	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public float getPerAge() {
		return perAge;
	}
	public void setPerAge(float perAge) {
		this.perAge = perAge;
	}

	public String toString() {
		return "perName=" + perName + "\nperAge=" + perAge;
	}
	
}
