public class NotValidAge extends RuntimeException {
	NotValidAge (String msg)
	{
		super(msg);
	} 

}

