
public class TestDrawingApp 
{

	public static void main(String[] args) 
	{
		Shape shape1=new Circle(5);
		Shape shape2=new Circle(2);
		Shape shape3=new Sphere(4);
		
		System.out.println("AREA :"+shape1.calcArea());
		System.out.println("PERIMETER :"+shape1.calcPerimeter());
		System.out.println("AREA :"+shape2.calcArea());
		System.out.println("PERIMETER :"+shape2.calcPerimeter());
		System.out.println("AREA :"+shape3.calcArea());
		System.out.println("VOLUME :"+((Sphere)shape3).calcVolume());
	}

}
