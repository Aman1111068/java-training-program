
public class Sphere extends Circle 
{
	public Sphere()
	{
		super();
	}
	public Sphere(int radius)
	{
		super(radius);
	}
	public double calcArea()
	{
		return (4*super.calcArea());
		// return ((4*Math.PI*getRadius()*getRadius()));
	}
	public double calcVolume()
	{
		return (4/3)*(super.calcArea()*radius);
		//return((4/3)*Math.PI*(Math.pow(getRadius(),3)));
	}
	

}
