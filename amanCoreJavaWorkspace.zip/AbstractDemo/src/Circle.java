
public class Circle extends Shape 
{
	/*private*/protected int radius;
   /*private*/ protected Circle()
    {
    	
    }
  /*private*/  protected Circle(int radius)
    {
    	this.radius=radius;
    }
    
    /*public int getRadius() 
    {
		return radius;
	}
	public void setRadius(int radius) 
	{
		this.radius = radius;
	}*/
	@Override
    public double calcArea()
    {
    	return (Math.PI*radius*radius);
    }
    public double calcPerimeter()
    {
    	return (2*Math.PI*radius);
    }
}
