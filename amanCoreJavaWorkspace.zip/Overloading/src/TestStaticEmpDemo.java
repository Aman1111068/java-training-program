
public class TestStaticEmpDemo 
{
	static
	{
		System.out.println("This is TestStaticEmpDemo static block");
	}
    public static void main(String[] args)
    {
    	System.out.println("Main starts Here");
    	Emp e1=new Emp(111,"vaishali",1000.0f);
    	Emp e2=new Emp(222,"aman",2000.0f);
    	Emp e3=new Emp(333,"divya",3000.0f);
    	System.out.println(e1.dispEmpInfo());
    	System.out.println(e2.dispEmpInfo());
    	System.out.println(e3.dispEmpInfo());
    	Emp.getCount();
    	//TestStaticEmpDemo t1=new TestStaticEmpDemo();
    	show();//t1.show();
    	
    }
    
    private static void show()
    {
    	System.out.println("static block show");
    }
}
