enum Seasons
{
	SUMMER,RAINY,WINTER,AUTUMN
}
public class TestEnumDemo 
{

	public static void main(String[] args) 
	{
		Seasons currSeason=Seasons.WINTER;
		System.out.println("Its:"+currSeason);

	}

}
