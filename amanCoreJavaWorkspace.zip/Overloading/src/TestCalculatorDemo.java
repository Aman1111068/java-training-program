class Calculator
{
	/*public void add(int a,int b)
	{
		System.out.println("addition of 2 integers:"+(a+b));
	}*/
	public void add(int a,int b,int c)
	{
		System.out.println("addition of 3 integers:"+(a+b+c));
	}
	public void add(byte a,byte b)
	{
		System.out.println("addition of byte:"+(a+b));
	}
	public void add(float a,float b)
	{
		System.out.println("addition of 2 float:"+(a+b));
	}
	public void add(String a,String b)
	{
		System.out.println("Full Name:"+(a+" " +b));
	}
	public void add(double a,double b)
	{
		System.out.println("addition of 2 double:"+(a+b));
	}
	public void add(Integer a,Integer b)//reference variable becuse class name Integer is used
	{
		System.out.println("2 integers wrapper:"+(a+b));
	}
}



public class TestCalculatorDemo 
{
     public static void main(String[] args)
     {
    	Calculator c = new Calculator();
    	c.add(10,20);
    	c.add(10,20,30);
    	c.add(10.22f,11.22f);
    	c.add("AMAN","SHRIVASTAVA");
    	c.add(10.22,11.22);
    	c.add((byte)10,(byte)20);
    	Integer i1=new Integer(10);
    	
    	c.add(i1,new Integer(20));
    	new Integer(20).toString();
     }
}
