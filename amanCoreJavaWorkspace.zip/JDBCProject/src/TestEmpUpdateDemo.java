import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpUpdateDemo 
{

	public static void main(String[] args) 
	{
		PreparedStatement pst;
		Scanner sc;
		Connection con=null;
		
		
		//Load oracle type 4 driver in memory
		try
		{
			
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		
		
		String UpdateQry="Update emp_142245 set emp_sal=emp_sal+10000 where emp_sal<20000";
		pst=con.prepareStatement(UpdateQry);
		
		int dataAdded=pst.executeUpdate();
		
		
				
		
		System.out.println("data Update in table:"+dataAdded);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
