import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpData2Demo 
{

	public static void main(String[] args) 
	{
		PreparedStatement pst;
		Scanner sc;
		Connection con=null;
		
		
		//Load oracle type 4 driver in memory
		try
		{
			sc=new Scanner(System.in);
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		
		System.out.println(" Enter Id:");
		int empId=sc.nextInt();
		
		System.out.println(" Enter Name:");
		String empName=sc.next();
		
		System.out.println(" Enter Salary:");
		float empSal=sc.nextFloat();
		
		
		
		String insertQry="insert into emp_142245(emp_id,emp_name,emp_sal)values(?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, empId);
		pst.setString(2, empName);
		pst.setFloat(3, empSal);
		
		int dataAdded=pst.executeUpdate();
		
		
				
		
		System.out.println("data Inserted in table:"+dataAdded);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
