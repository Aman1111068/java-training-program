import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestEmpAddDemo 
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;
		
		//Load oracle type 4 driver in memory
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		st=con.createStatement();
		String insertQry="insert into emp_142245(emp_id,emp_name,emp_sal)values(444,'VAISHALI',4000.0)";
				
		int data=st.executeUpdate(insertQry);
		System.out.println("data Inserted in table:"+data);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
