import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestEmpSelectDemo 
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;;
		//Load oracle type 4 driver in memory
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		st=con.createStatement();
		String selQry="SELECT * from emp_142245";
		rs=st.executeQuery(selQry);
		while(rs.next())
		{
		System.out.println("ID\t NAME\t SALARY\t DOJ");
		System.out.println(rs.getInt("emp_id")+"\t"
				+rs.getString("emp_name")+"\t"
				+rs.getInt("emp_sal")+"\t"
				+rs.getDate("emp_doj"));
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
