import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpAddNDemo 
{

	public static void main(String[] args) 
	{
		PreparedStatement pst;
		Scanner sc;
		Connection con=null;


		//Load oracle type 4 driver in memory
		try
		{
			sc=new Scanner(System.in);
			System.out.println("How many rows you want to add?");
			int limit=sc.nextInt();
			int dataAdded;
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String insertQry="insert into emp_142245(emp_id,emp_name,emp_sal)values(?,?,?)";
			pst=con.prepareStatement(insertQry);
		
			for(int i=1;i<=limit;i++)
			{

				System.out.println(" Enter Id:");
				int empId=sc.nextInt();

				System.out.println(" Enter Name:");
				String empName=sc.next();

				System.out.println(" Enter Salary:");
				float empSal=sc.nextFloat();
				pst.setInt(1, empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);

				dataAdded=pst.executeUpdate();
				System.out.println("data Inserted in table:"+dataAdded);
			}
		}
			
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
