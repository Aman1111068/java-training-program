import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpDelDemo 
{

	public static void main(String[] args) 
	{
		PreparedStatement pst;
		Scanner sc;
		Connection con=null;


		//Load oracle type 4 driver in memory
		try
		{
			sc=new Scanner(System.in);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String delQry="delete from emp_142245 where emp_id =?";
			pst=con.prepareStatement(delQry);
			System.out.println(" Enter Id:");
			int empId=sc.nextInt();
			
			pst.setInt(1, empId);
			int dataAdded=pst.executeUpdate();
			System.out.println("data deleted from table:"+dataAdded);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
