import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestMenuEmpDemo 
{

	public static void main(String[] args) 
	{
		PreparedStatement pst;
		Statement st=null;
		Connection con=null;
		int choice;
		Scanner sc=new Scanner(System.in);
		ResultSet rs;
		System.out.println("Enter your choice.\n"
				+ "1.Insert rows\n"
				+ "2.Delete rows using Employee Id\n"
				+ "3.Update salary of employee by 10000 using Employee Id\n"
				+ "4.Update salary of employees by 10000 having salary less than 20000\n"
				+ "5.Select all columns based on Employee Id\n"
				+ "6.Select all columns in Employee table\n"
				+ "7.Exit\n");
		choice=sc.nextInt();
		try
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
		("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			switch(choice)
			{
			case 1:
				int count=0;
				System.out.println("How many rows you want to add?");
			int limit=sc.nextInt();
				String insertQry="insert into emp_142245(emp_id,emp_name,emp_sal)values(?,?,?)";
			pst=con.prepareStatement(insertQry);
			for(int i=1;i<=limit;i++)
			{

				System.out.println(" Enter Id:");
				int empId=sc.nextInt();

				System.out.println(" Enter Name:");
				String empName=sc.next();

				System.out.println(" Enter Salary:");
				float empSal=sc.nextFloat();
				pst.setInt(1, empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);

				pst.executeUpdate();
				count++;
				
			}
			System.out.println("data Inserted in table:"+count);
			break;
			
			case 2:
				String delQry="delete from emp_142245 where emp_id =?";
				pst=con.prepareStatement(delQry);
				System.out.println(" Enter Id:");
				int empId=sc.nextInt();
				pst.setInt(1, empId);
				int dataAdded=pst.executeUpdate();
				System.out.println("data deleted from table:"+dataAdded);
				break;
				
			case 3:
				String UpdateQry="Update emp_142245 set emp_sal=emp_sal+10000 where emp_id=?";
				pst=con.prepareStatement(UpdateQry);
				System.out.println(" Enter Id:");
				int empid=sc.nextInt();
				pst.setInt(1, empid);
				int data=pst.executeUpdate();
				System.out.println("data Updated in table:"+data);
				break;
			
			case 4:
				String UpdateQuery="Update emp_142245 set emp_sal=emp_sal+10000 where emp_sal<20000";
				pst=con.prepareStatement(UpdateQuery);
				int dataUpdate=pst.executeUpdate();
				System.out.println("data Updated in table:"+dataUpdate);
				break;
				
			case 5:
				String selQry="SELECT * from emp_142245 where emp_id=?";
				pst=con.prepareStatement(selQry);
				System.out.println(" Enter Id:");
				int eid=sc.nextInt();
				pst.setInt(1, eid);
				rs=pst.executeQuery();
				rs.next();
				System.out.println(rs.getInt("emp_id")+"\t"
						+rs.getString("emp_name")+"\t"
						+rs.getInt("emp_sal"));
				System.out.println("Rows Selected");
				break;
				
			case 6:
				st=con.createStatement();
				String selectQry="SELECT * from emp_142245";
				rs=st.executeQuery(selectQry);
				while(rs.next())
				{
				System.out.println("ID\t NAME\t SALARY\t DOJ");
				System.out.println(rs.getInt("emp_id")+"\t"
						+rs.getString("emp_name")+"\t"
						+rs.getInt("emp_sal"));
				
				}
				break;
			
			default:
				break;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
