import java.util.Arrays;
import java.util.List;


public class TestStreamAPIDemo 
{

	public static void main(String[] args) 
	{
		List<String> cityList= Arrays.asList("Pune","Mumbai","Nagpur","",
				"Gaziabad","Mumbai","Delhi","");
		
		
				cityList.stream().distinct().forEach(System.out::println);
				long cityCount=cityList.stream().distinct().count();
				System.out.println(" How Many Cities ?"+
				cityCount);
				
				cityList.stream().distinct().map(str->str.length()).forEach(System.out::println);
				long emptyStrCount=cityList.stream().filter((String str)->str.isEmpty()).count();
				System.out.println(" Empty String ?"+
						emptyStrCount);
	}

}
