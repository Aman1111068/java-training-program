import java.util.Scanner;


public class TestMedicineDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		String medName="";
		String comName="";
		Date expr;
		float price=0.0f;
		int dd,mm,yy;
		System.out.println("How many Medicines to show?");
		int medCount=sc.nextInt();
		Medicine medArr[]=new Medicine[medCount];
		 expr=new Date();
		for (int i=0;i<medArr.length;i++)
		{
			System.out.println("Enter Medicine Name: ");
			medName=sc.next();
			System.out.println("Enter Company Name: ");
			comName=sc.next();
			System.out.println("Enter Day of Expiry: ");
			dd=sc.nextInt();
			System.out.println("Enter Month of Expiry: ");
			mm=sc.nextInt();
			System.out.println("Enter Year of Expiry: ");
			yy=sc.nextInt();
			System.out.println("Enter Price: ");
			price=sc.nextFloat();
			System.out.println("What type of Medicine"+medName+" is 1:TABLET\t 2:OINTMENT\t 3:SYRUP");
			System.out.println("Enter Choice:");
			int choice=sc.nextInt();
			expr=new Date(dd,mm,yy);
			medArr[i]=new Medicine(medName,comName,expr,price);
			switch(choice)
			{
			
			case 1:
				medArr[i]= new Tablet(medName,comName,expr,price);
				
				break;
			case 2:
				medArr[i]= new Ointment(medName,comName,expr,price);
				
				break;
				
			default:
				medArr[i]= new Syrup(medName,comName,expr,price);
				
				break;
			}
			
		}
		
		     for(int j=0;j<medArr.length;j++)
		     {
		    	 if(medArr[j] instanceof Tablet)
		    	 {
		    		 System.out.println("Tablet Details:"+medArr[j].dispMedInfo()); 
		    	 }
		    	 else if(medArr[j] instanceof Ointment)
		    	 {
		    		 System.out.println("Ointment Details:"+medArr[j].dispMedInfo()); 
		    	 }
		    	 else if(medArr[j] instanceof Syrup)
		    	 {
		    		 System.out.println("Syrup Details:"+medArr[j].dispMedInfo()); 
		    	 }
		     }

	}

}
