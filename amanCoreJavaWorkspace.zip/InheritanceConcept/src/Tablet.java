
public class Tablet extends Medicine
{
	private String howToUse="Store in cool and dry place";

	public Tablet(String medicineName,String companyName,Date expiryDate,float price) 
	{
		super(medicineName,companyName,expiryDate,price);
		
	}
	public String dispMedInfo()
	{
		 return super.dispMedInfo()+"HOW TO USE"+howToUse;
	}

}
