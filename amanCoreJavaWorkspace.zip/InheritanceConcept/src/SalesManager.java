
public class SalesManager extends WageEmp 
{
	private int sale;
	private float commision;
	public SalesManager()
	{
		super();
	}
	public SalesManager(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs,int sale,float commision) 
	{
		super(empId,empName,empSal,noOfHrs,ratePerHrs);
		this.sale = sale;
		this.commision = commision;
	}
	public float calcEmpBasicSal()//OVERRIDING PARENT CLASS FUNCTIONS
	{
		return super.calcEmpBasicSal()+(sale*commision);
			
	}
	public float calcEmpAnnualSal()//OVERRIDING PARENT CLASS FUNCTIONS
	{
		return calcEmpBasicSal()*12;
	}

}
