
public class Ointment extends Medicine
{
	
		private String howToUse="For external use only.";

		public Ointment(String medicineName,String companyName,Date expiryDate,float price) 
		{
			super(medicineName,companyName,expiryDate,price);
		
		}
		public String dispMedInfo()
		{
			 return super.dispMedInfo()+"HOW TO USE"+howToUse;
		}

	

}
