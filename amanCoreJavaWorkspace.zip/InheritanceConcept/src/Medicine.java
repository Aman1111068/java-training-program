
public class Medicine 
{
	private String medicineName;
	private String companyName;
	 Date expiryDate;
	private float price;
	
	
	public Medicine() 
	{
		expiryDate=new Date();
		
	}
	public Medicine(String medicineName, String companyName,Date expiryDate,float price) 
	{
		super();
		this.medicineName = medicineName;
		this.companyName = companyName;
		this.expiryDate = expiryDate; 
		this.price = price;
	}
	public String dispMedInfo()
	{
		 return "Medicine Name:"+medicineName+
				"Company Name:"+companyName+
				"Expiry Date:"+expiryDate.dispDate()+
				"Price of Medicine:"+
				price;
	}
	

}
