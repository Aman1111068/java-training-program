
public class Syrup extends Medicine
{
	private String howToUse="Shake well before use.";

	public Syrup(String medicineName,String companyName,Date expiryDate,float price) 
	{
		super(medicineName,companyName,expiryDate,price);
		
	}
	public String dispMedInfo()
	{
		 return super.dispMedInfo()+"HOW TO USE"+howToUse;
	}

}
