import java.util.Scanner;
public class TestInheritanceDemo1 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Employee?");
		int empCount=sc.nextInt();
		Employee empArr[]=new Employee[empCount];
		int eId=0;
		String ename=null;
		float esal=0.0f;
		int ratePerHr=0;
		int noOfHrs=0;
		for (int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter Emp Id: ");
			eId=sc.nextInt();
			System.out.println("Enter Emp Name: ");
			ename=sc.next();
			System.out.println("Enter Emp Salary: ");
			esal=sc.nextFloat();
			System.out.println("What type of Emp"+ename+" is 1:EMP\t 2:WageEmp\t 3:Sales Manager");
			System.out.println("Enter Choice:");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:empArr[i]=new Employee(eId,ename,esal);
			break;
			case 2:
				System.out.println("Enter number of working hours");
				 noOfHrs=sc.nextInt();
				System.out.println("Enter Rate per Hour");
				 ratePerHr=sc.nextInt();
				empArr[i]=new WageEmp(eId,ename,esal,noOfHrs,ratePerHr);
				break;
			default:
				System.out.println("Enter number of working hours");
				noOfHrs=sc.nextInt();
				System.out.println("Enter Rate per Hour");
				 ratePerHr=sc.nextInt();
				System.out.println("wHAT SALE YOU HAVE DONE");
				int sale=sc.nextInt();
				System.out.println("WHAT IS THE FRACTION OF COMMISION YOU ARE GETTING OUT OF 1?");
				 float commision=sc.nextFloat();
				empArr[i]=new SalesManager(eId,ename,esal,noOfHrs,ratePerHr,sale,commision);
				break;
			}
			
		}
		
		System.out.println("****************************************");
		for(int j=0;j<empArr.length;j++)
		{
			if(empArr[j] instanceof SalesManager)
			{
				System.out.println("Sales Manager:"+empArr[j].dispEmpInfo()+
						           "Monthly Basic Salary:"+empArr[j].calcEmpBasicSal()+
						           "Annual Salary:"+empArr[j].calcEmpAnnualSal());
			}
			else if(empArr[j] instanceof WageEmp)
			{
				System.out.println("Wage Employee:"+empArr[j].dispEmpInfo()+
						           "Monthly Basic Salary:"+empArr[j].calcEmpBasicSal()+
						           "Annual Salary:"+empArr[j].calcEmpAnnualSal());
			}
			else if(empArr[j] instanceof Employee)
			{
				System.out.println("Employee:"+empArr[j].dispEmpInfo()+
						           "Monthly Basic Salary:"+empArr[j].calcEmpBasicSal()+
						           "Annual Salary:"+empArr[j].calcEmpAnnualSal());
			}
		}

	}

}
