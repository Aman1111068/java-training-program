
public class TestInheritanceDemo 
{

	public static void main(String[] args) 
	{
		Employee e1=new Employee(111,"Vaishali S",20000.0f);
		WageEmp e2=new WageEmp(222,"Aman S",300.0f,400,5);
	    System.out.println(" Emp Info:"+e1.dispEmpInfo());
	    System.out.println(" Emp Monthly Sal:"+e1.calcEmpBasicSal());
	    System.out.println(" Emp Annual Sal:"+e1.calcEmpAnnualSal());
	    
	    System.out.println(" Emp Info:"+e2.dispEmpInfo());
	    System.out.println(" Wage Emp Monthly Sal:"+e2.calcEmpBasicSal());
	    System.out.println(" Wage Emp Annual Sal:"+e2.calcEmpAnnualSal());
	     
	    Employee e3=new WageEmp(333,"Kritika",400.0f,200,10);//genralization concept && Dynamic Binding
	    System.out.println(" Emp Info:"+e3.dispEmpInfo());
	    System.out.println(" Wage Emp Monthly Sal:"+e3.calcEmpBasicSal());
	    System.out.println(" Wage Emp Annual Sal:"+e3.calcEmpAnnualSal());
	    /*WageEmp we=(WageEmp)e3;
	    System.out.println(" Emp Info:"+we.dispEmpInfo());
	    System.out.println(" Wage Emp Monthly Sal:"+we.calcEmpBasicSal());
	    System.out.println(" Wage Emp Annual Sal:"+we.calcEmpAnnualSal());
	*/
	    
	    SalesManager e4=new SalesManager(444,"Divya K",300.0f,400,5,100000,0.02f);
	    System.out.println(" Emp Info:"+e4.dispEmpInfo());
	    System.out.println(" Wage Emp Monthly Sal:"+e4.calcEmpBasicSal());
	    System.out.println(" Wage Emp Annual Sal:"+e4.calcEmpAnnualSal());
	    
	    
	    
	    
	}

}
