import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
																																																										

public class TestDateDemos 
{

	public static void main(String[] args) 
	{
		LocalDate today=LocalDate.now();
		System.out.println(" Today Date: "+ today);
		System.out.println("******************");
        LocalDate myDOJ=LocalDate.of(2017, 12, 13);
        System.out.println(" My DOJ: "+ myDOJ);
        System.out.println("******************");
        String amanDOJ="13-Dec-2017";
        DateTimeFormatter myformat= DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        LocalDate amanDoj=LocalDate.parse(amanDOJ,myformat);
        System.out.println(" AMAN DOJ: "+ amanDoj);
        System.out.println("******************");
        DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        String urDOJ =amanDoj.format(secondFormat);
        System.out.println("...."+urDOJ);
        System.out.println("******************");
        Period period=Period.between(myDOJ, today);
        int years=period.getYears();
        int months=period.getMonths();
        int days=period.getDays();
        System.out.println("my Exp In CG is :"+years+"Years:"+months+"Month :"+days+" Days");
        
	}

}
