package com.cg.eis.bean;

public class Employee 
{
	private int empId;
	private String empName;
	private int empSal;
	private String designation;
	private String insuranceScheme;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public Employee() {
		super();
	
	}
	public Employee(int empId, String empName, int empSal, String designation,
			String insuranceScheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}
	
	public String dispEmployeeInfo() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}
	
	

}
