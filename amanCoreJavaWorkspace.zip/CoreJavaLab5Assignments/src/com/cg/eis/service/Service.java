package com.cg.eis.service;

public class Service implements EmployeeService
{
   
}
