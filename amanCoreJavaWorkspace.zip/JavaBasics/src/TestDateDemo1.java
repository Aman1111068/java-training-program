import java.util.Scanner;


public class TestDateDemo1 
{

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);
		Date allDojs[]=new Date[3];
		String name[]=new String[3];
		int day=0,mon=0,year=0;
		
		
	    for(int i=0;i<allDojs.length;i++)
	    {
	    System.out.println("Enter Your Name :");
	    name[i]=sc.next();
	    System.out.println("Enter Day of JOINNING:");
	    day=sc.nextInt();
	    System.out.println("Enter Month of JOINNING:");
	    mon=sc.nextInt();
	    System.out.println("Enter Year of JOINNING:");
	    year=sc.nextInt();
        
	    allDojs[i]=new Date(day,mon,year);
	    }
	    
	    for(int j=0;j<allDojs.length;j++)
	    {
	    	System.out.println("DOJ :"+allDojs[j].dispDate());
	    	System.out.println("NAME:"+name[j]);
	    }
	    
	    

	}

}
