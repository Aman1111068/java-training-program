
public class Employee 
{
	private int empId;
	private String empName;
	private float empSalary;
	private char gender;
	
	public Employee()
	{
		empId= 0;
		empName="Unknown";
		empSalary= 0.0f;
		gender=' ';
		
	}
	public Employee(int empId,String empName,float empSalary,char gender)
	{
		
		this.empId=empId;
		this.empName=empName;
		this.empSalary=empSalary;
		this.gender=gender;
	}
	public String dispEmp()
	{
		return empId+"\n"+empName+"\n"+empSalary+"\n"+gender;
	}
	public float calcBasicSal()
	{
		return empSalary;
	}

}
