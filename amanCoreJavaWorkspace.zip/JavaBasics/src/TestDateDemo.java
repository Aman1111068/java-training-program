import java.util.Scanner;


public class TestDateDemo 
{

	public static void main(String[] args) 
	{
		    Scanner sc =new Scanner(System.in);
		    
		    System.out.println("Enter Day :");
		    int dayOfDoj=sc.nextInt();
		    
            
		    
		    System.out.println("Enter Month :");
		    int monthOfDoj=sc.nextInt();
		    
           
		    
		    System.out.println("Enter Year :");
		    int yearOfDoj=sc.nextInt();
		    
		    Date amanDOJ=new Date(dayOfDoj,monthOfDoj,yearOfDoj);
		    
		    System.out.println("AMAN DOJ IS:"+amanDOJ.dispDate());
		    
		    System.out.println("Enter Day :");
		    int dayOfDoj1=sc.nextInt();
		    
            
		    
		    System.out.println("Enter Month :");
		    int monthOfDoj1=sc.nextInt();
		    
           
		    
		    System.out.println("Enter Year :");
		    int yearOfDoj1=sc.nextInt();
		    
		    Date vaiDOJ=new Date(dayOfDoj1,monthOfDoj1,yearOfDoj1);
		    
		    System.out.println("VAISHALI DOJ IS:"+vaiDOJ.dispDate());
		    

	}

}
