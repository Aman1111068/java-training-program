
public class Employee 
{
    private int empId;
    private String empName;
    private float empSal;
    private char gender;
    Date empDOJ;
    
    public Employee()
    {
    	empId=0;
    	empName="Unknown";
    	empSal=0.0f;
    	gender=' ';
    	empDOJ=new Date();
    }

	public Employee(int empId, String empName, float empSal,char gender,Date empDOJ) 
	{
		
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.gender = gender;
		this.empDOJ = empDOJ;
	}

	
	public String dispEmpInfo() 
	{
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", gender=" +gender+", empDOJ=" + empDOJ.dispDate() + "]";
	}
	
    
}
