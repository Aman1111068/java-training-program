import java.util.Scanner;


public class TestEmpAggregationDemo1 
{

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);
		int limit;
		System.out.println("How many employees details you want to return?");;
		limit=sc.nextInt();
		Date empDOJ=new Date();
		Employee allEmps[]=new Employee[limit];
		int eid=0;
		String ename="";
		float esal=0f;
		char gen=' ';
		String gender="";
		int day=0;
		int month=0;
		int year=0;

		for(int i=0;i<allEmps.length;i++)
		{
			System.out.println("Enter Your Employee ID :");
			eid=sc.nextInt();
			System.out.println("Enter Name of Employee:");
			ename=sc.next();
			System.out.println("Enter Salary of Employee:");
			esal=sc.nextFloat();
			System.out.println("Enter Gender of Employee:");
			gender=sc.next();
			gen=gender.charAt(0);
			System.out.println("Enter Day of Joinning :");
			day=sc.nextInt();
			System.out.println("Enter Month of Joinning:");
			month=sc.nextInt();
			System.out.println("Enter Month of Joinning:");
			year=sc.nextInt();
            empDOJ=new Date(day,month,year);
			allEmps[i]=new Employee(eid,ename,esal,gen,empDOJ);
		}

		for(int j=0;j<allEmps.length;j++)
		{
			System.out.println("EMPLOYEE DETAILS :"+allEmps[j].dispEmpInfo());

		}

	}

}
