
public class TestEmployeeAggregationDemo 
{
	public static void main(String[] args)
	{
		Date vaiDOJ=new Date(10,04,2015);
		Date roshanDOJ=new Date(13,12,2017);
		
		Employee vaishali= new Employee(112081,
				"Vaishali S",1000.0f,'M',vaiDOJ);
		Employee roshan= new Employee(34567,
				"Roshan",2000.0f,'F',roshanDOJ);
		
		System.out.println(vaishali.dispEmpInfo());
		System.out.println(roshan.dispEmpInfo());
	}

}
