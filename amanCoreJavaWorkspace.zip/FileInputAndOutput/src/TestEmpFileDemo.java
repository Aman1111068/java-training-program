import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestEmpFileDemo {

	public static void main(String[] args) 
	{
		try
		{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println(" Enter Emp Id :");
		int eid=Integer.parseInt(br.readLine());
		
		System.out.println(" Enter Your Name :");
		String ename=br.readLine();
		
		System.out.println(" Enter Emp Salary :");
		float esal=Float.parseFloat(br.readLine());
		
		System.out.println(eid+" "+ename+" "+esal);
		FileWriter fw=new FileWriter("EmpInfo.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		Integer eIdS=new Integer(eid);//boxing(converting primitive type into objects)(Using wrapper class because of toString())
		Float esIS=new Float(esal);
		bw.write(eIdS.toString());
		bw.write(" ");
		bw.write(ename);
		bw.write(" ");
		bw.write(esIS.toString());
		bw.newLine();
		bw.flush();
		System.out.println(" Emp Info written in a file");
		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	
	

}
