import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationDemoN 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("HOW MANY EMPLOYEE OBJECTS YOU WANT TO CREATE?");
		int emp=sc.nextInt();
		Emp emps[]=new Emp[emp];
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try
		{
			fos=new FileOutputStream("EmpData2.obj");
		    oos=new ObjectOutputStream(fos);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		try
		{
		for(int i=0;i<emps.length;i++)
		{
		
		System.out.println("Enter emp id");
		int empId=sc.nextInt();
		System.out.println("Enter emp Name");
		String empName=sc.next();
		System.out.println("Enter emp salary");
		float empSal=sc.nextFloat();
		emps[i]=new Emp(empId,empName,empSal);
		oos.writeObject(emps[i]);
		System.out.println("emp object is written in a file");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}

}
