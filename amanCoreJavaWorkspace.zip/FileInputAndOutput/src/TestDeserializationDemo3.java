import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class TestDeserializationDemo3 
{
	
	public static void main(String[] args) 
	{
		Emp emps[]=new Emp[3];
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try
		{
			fis=new FileInputStream("EmpData1.obj");
		    ois=new ObjectInputStream(fis);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		for(int i=0;i<emps.length;i++)
		{
		try
		{
			
			emps[i]=(Emp)ois.readObject();
			System.out.println(emps[i]);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		}
	}

}
