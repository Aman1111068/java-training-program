import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Scanner;


public class TestDeserializationDemoN 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("HOW MANY EMPLOYEE OBJECTS YOU WANT TO SHOW?");
		int emp=sc.nextInt();
		Emp emps[]=new Emp[emp];
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try
		{
			fis=new FileInputStream("EmpData2.obj");
		    ois=new ObjectInputStream(fis);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		for(int i=0;i<emps.length;i++)
		{
		try
		{
			
			emps[i]=(Emp)ois.readObject();
			System.out.println(emps[i]);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		}


	}

}
