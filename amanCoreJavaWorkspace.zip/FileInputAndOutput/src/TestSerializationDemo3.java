import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationDemo3 
{

	public static void main(String[] args) 
	{
		Emp emps[]=new Emp[3];
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try
		{
			fos=new FileOutputStream("EmpData1.obj");
		    oos=new ObjectOutputStream(fos);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		try
		{
		for(int i=0;i<emps.length;i++)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter emp id");
		int empId=sc.nextInt();
		System.out.println("Enter emp Name");
		String empName=sc.next();
		System.out.println("Enter emp salary");
		float empSal=sc.nextFloat();
		emps[i]=new Emp(empId,empName,empSal);
		oos.writeObject(emps[i]);
		System.out.println("emp object is written in a file");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}

}
