import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class TestPropertyFileDemo 
{

	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try
		{
		 fr=new FileReader("userInfo.properties");
		 props=new Properties();
		 props.load(fr);
		 System.out.println("****all data****");
		 for(int j=0;j<props.size();j++)
		 {
			String unm=props.getProperty("username");
			String pwd=props.getProperty("password");
			String location=props.getProperty("location");
			String state=props.getProperty("state");
			System.out.println(" User Info: "+ unm+" "+pwd+" "+location+" "+state);
		 }
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}

}
