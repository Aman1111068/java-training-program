import java.util.Scanner;


public class TestBankAppDemo 
{

	public static void main(String[] args) //throws LowBalanceException
	{
		Scanner sc=new Scanner(System.in);
		
        int currentBalance=60000;
        System.out.println(""+"Enter the withdraw amount");
        int withdrawAmt=sc.nextInt();
        if(withdrawAmt<currentBalance)
        {
        	System.out.println("OK U have"+"sufficient balance. you can withdraw");
        }
        else
        { 
        	throw new LowBalanceException("Please Chk balance of your Account");
        	/*try
        	{
        	throw new LowBalanceException("Please Chk balance of your Account");
        }
        	catch(LowBalanceException e)
        	{
        		System.out.println("Insufficient Balance in your account");
        		e.printStackTrace();
        	}*/
        
        	}
	}

}
