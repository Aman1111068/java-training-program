import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

@FunctionalInterface
interface MaxFinder
{
	public int max(int num1,int num2);
}
/*class MaxFinderImpl implements MaxFinder
{
	@Override
	public int max(int num1, int num2) 
	{
		
		return num1>num2?num1:num2;
	}

}*/
public class TestScannerDemo {

	public static void main(String[] args)
	{
	/*MaxFinder mf=new MaxFinderImpl();
	int max=mf.max(90, 30);
	 System.out.println("Greatest number is : "+max);*/
	/*MaxFinder mf=(num1,num2)->num1>num2?num1:num2;
    System.out.println("Greatest number is : "+mf.max(60, 90));
	}*/
    Consumer<String> consumer=(String str)->System.out.println(str);
    consumer.accept("Welcome");
    Supplier<String> sup=()->"Happy New Year";
    System.out.println(sup.get());
    
    BiFunction<Integer,Integer,Integer>
    biFunction= (x,y)->x>y?x:y;
    System.out.println("Greatest number is : "+biFunction.apply(60, 90));
    
    Predicate<Integer> predicate=(num)->num%2==0;
    System.out.println("Is 4 Even No?"+
    predicate.test(4));
    System.out.println("Is 3 Even No?"+
    	    predicate.test(3));
    }

}
