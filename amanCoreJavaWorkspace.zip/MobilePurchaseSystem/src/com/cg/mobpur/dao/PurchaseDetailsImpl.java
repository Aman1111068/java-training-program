package com.cg.mobpur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;





import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.util.DBUtil;

public class PurchaseDetailsImpl implements PurchaseDetailsDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int insertCustomer(PurchaseDetails pd) throws MobileException 
	{
		String insertQry="INSERT INTO purchaseDetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileId) values(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		
		
			try 
			{

				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1, generatePurchaseId());
				pst.setString(2, pd.getCustomerName());
				pst.setString(3, pd.getMailId());
				pst.setLong(4, pd.getPhoneNo());
				pst.setInt(5, pd.getMobileId());
				System.out.println(pd.getCustomerName());

				dataAdded=pst.executeUpdate();


			} 
			catch (Exception e)
			{

				throw new MobileException(e.getMessage());

			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{

					throw new MobileException(e.getMessage());

				}

			

		    }

		return dataAdded;

	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="SELECT purchase_seq.nextval from dual";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		} 
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{

				throw new MobileException(e.getMessage());
			}
		}

		return generatedVal;
	}
    

}


