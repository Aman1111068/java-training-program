package com.cg.mobpur.dao;

import java.util.ArrayList;

import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;

public interface PurchaseDetailsDao 
{
	
    public int insertCustomer(PurchaseDetails pd)throws MobileException;
	public int generatePurchaseId()throws MobileException;
}
