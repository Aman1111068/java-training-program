package com.cg.mobpur.bean;

import java.sql.Date;

public class PurchaseDetails 
{
	private String customerName;
	private String mailId;
	private long phoneNo;
	private int mobileId;
	private int purchaseId;
	private Date purchaseDate;
	public PurchaseDetails()
	{
		super();
	
	}
	public PurchaseDetails(String customerName, String mailId, long phoneNo,
			int mobileId, int purchaseId, Date purchaseDate) 
	{
		super();
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.purchaseId = purchaseId;
		this.purchaseDate = purchaseDate;
	}
	
	public PurchaseDetails(String customerName, String mailId, long phoneNo,
			int mobileId, int purchaseId) {
		super();
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.purchaseId = purchaseId;
	}
	public String getCustomerName() 
	{
		return customerName;
	}
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public String getMailId() 
	{
		return mailId;
	}
	public void setMailId(String mailId) 
	{
		this.mailId = mailId;
	}
	public long getPhoneNo() 
	{
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo)
	{
		this.phoneNo = phoneNo;
	}
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public int getPurchaseId() 
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) 
	{
		this.purchaseId = purchaseId;
	}
	public Date getPurchaseDate() 
	{
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [customerName=" + customerName + ", mailId="
				+ mailId + ", phoneNo=" + phoneNo + ", mobileId=" + mobileId
				+ ", purchaseId=" + purchaseId + ", purchaseDate="
				+ purchaseDate + "]";
	}
	

}
