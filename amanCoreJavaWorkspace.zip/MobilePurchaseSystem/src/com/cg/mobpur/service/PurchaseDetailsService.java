package com.cg.mobpur.service;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;

public interface PurchaseDetailsService 
{
	public int insertCustomer(PurchaseDetails pd)throws MobileException;
	public int generatePurchaseId()throws MobileException;

	
	public boolean validateName(String cname) throws MobileException;
	public boolean validateMailId(String mailId) throws MobileException;
	public boolean validatePhoneNo(long phoneNo) throws MobileException;
	
	
}
