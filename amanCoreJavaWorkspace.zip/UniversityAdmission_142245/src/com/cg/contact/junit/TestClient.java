package com.cg.contact.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.apply.dao.ApplyDao;
import com.cg.apply.dao.ApplyDaoImpl;
import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;

public class TestClient 
{
	static ApplyDao apdao=null;
	static ApplicantBean ap=null;
	@BeforeClass
    public static void beforeClass() throws ApplicantException
    {
        apdao=new ApplyDaoImpl();
        ap=new ApplicantBean(apdao.generateApplyId(),"Aman","Shrivastava",8109453231l,"aman@gmail.com",90.2F,"CS");
    }
    @Test
    public void testAddApplicant1() throws ApplicantException
    {
        Assert.assertEquals(1,apdao.addApplicantDetails(ap));
    }
    @Test
    public void testSelect1() throws ApplicantException
    {
        Assert.assertNotNull(apdao.getAllApplicantId());
    }
    @Test
    public void testSelect2() throws ApplicantException
    {
        Assert.assertNotNull(apdao.getApplicantDetails(1004));
    }
    
}
