package com.cg.contact.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.apply.dao.ApplyDao;
import com.cg.apply.dao.ApplyDaoImpl;
import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;




public class ApplyServiceImpl implements ApplyService 
{
   ApplyDao apDao=null;
   
	public ApplyServiceImpl() 
	{
		apDao=new ApplyDaoImpl();
		
	}

	@Override
	public int addApplicantDetails(ApplicantBean ab) throws ApplicantException 
	{
		
		return apDao.addApplicantDetails(ab);
	}

	@Override
	public long generateApplyId() throws ApplicantException 
	{
		
		return apDao.generateApplyId();
	}

	@Override
	public ArrayList<ApplicantBean> getApplicantDetails(long applyId)
			throws ApplicantException 
	{


		return apDao.getApplicantDetails(applyId);
	}

	

	@Override
	public boolean validateContactNo(long contactNo) throws ApplicantException 
	{
		
		String phoneNoPattern="[987]{1}[0-9]{9}";
		if(Pattern.matches(phoneNoPattern,new Long(contactNo).toString()))
				{
			return true;
				}
		else
		{
		throw new ApplicantException("Not a valid Phone Number.Should be 10 digits starting with 7 or 8 or 9.");	
		}
	}

	@Override
	public boolean validateFirstName(String fname) throws ApplicantException {
		
		String cnamePattern="[A-Z][A-Za-z]{2,20}";
		if(Pattern.matches(cnamePattern,fname))
				{
			return true;
				}
		else
		{
		throw new ApplicantException("Valid value should contain maximum 20 alphabets. "
				+ "Out of 20 Characters, first character should be in UPPERCASE."
				+ "First Name cannot be empty.");	
		}
	}

	@Override
	public boolean validateLastName(String lname) throws ApplicantException 
	{
		String cnamePattern="[A-Z][A-Za-z]{2,20}";
		if(Pattern.matches(cnamePattern,lname))
				{
			return true;
				}
		else
		{
		throw new ApplicantException("Valid value should contain maximum 20 alphabets. "
				+ "Out of 20 Characters, first character should be in UPPERCASE."
				+ "Last Name cannot be empty.");	
		}
		
	}

	@Override
	public boolean validateEmail(String email) throws ApplicantException 
	{
		String mailIdPattern="[A-Za-z0-9]+[@][a-z]+[/.][a-z]+";
		if(Pattern.matches(mailIdPattern,email))
				{
			return true;
				}
		else
		{
		throw new ApplicantException("Not a valid EmailId");	
		}
		
	}

	@Override
	public boolean validateAggregate(float aggregate) throws ApplicantException {
		
		String mobileIdPattern="[1-9][0-9]{1}[/.][0-9]{1}";
		if(Pattern.matches(mobileIdPattern,new Float(aggregate).toString()))
				{
			return true;
				}
		else
		{
		throw new ApplicantException("Not a valid Aggregate.Aggregate should not be empty.");	
		}
	}

	@Override
	public boolean validateStream(String stream) throws ApplicantException 
	{
		String cs="CS";
		String it="IT";
		if(Pattern.matches(cs,stream)||Pattern.matches(it, stream))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Stream can be only CS or IT");
		}
	}

	@Override
	public ArrayList<Long> getAllApplicantId() throws ApplicantException {
		
		return apDao.getAllApplicantId();
	}

	@Override
	public boolean validateApplicantId(long applyId) throws ApplicantException 
	{
		ArrayList<Long> appId= apDao.getAllApplicantId();
		
		for(Long a:appId)
		{
			if(applyId==a)
			{
				return true;
			}
		}
		return false;
	}
	

}
