package com.cg.contact.bean;

public class ApplicantBean 
{
	private long applyId;
	private String fName;
	private String lName;
	private long contactNo;
	private String email;
	private float aggregate;
	private String stream;
	public ApplicantBean() 
	{
		super();

	}
	public ApplicantBean(long applyId, String fName, String lName,
			long contactNo, String email, float aggregate, String stream) 
	{
		super();
		this.applyId = applyId;
		this.fName = fName;
		this.lName = lName;
		this.contactNo = contactNo;
		this.email = email;
		this.aggregate = aggregate;
		this.stream = stream;
	}
	public long getApplyId() 
	{
		return applyId;
	}
	public void setApplyId(long applyId) 
	{
		this.applyId = applyId;
	}
	public String getfName() 
	{
		return fName;
	}
	public void setfName(String fName) 
	{
		this.fName = fName;
	}
	public String getlName() 
	{
		return lName;
	}
	public void setlName(String lName) 
	{
		this.lName = lName;
	}
	public long getContactNo() 
	{
		return contactNo;
	}
	public void setContactNo(long contactNo) 
	{
		this.contactNo = contactNo;
	}
	public String getEmail() 
	{
		return email;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}
	public float getAggregate() 
	{
		return aggregate;
	}
	public void setAggregate(float aggregate) 
	{
		this.aggregate = aggregate;
	}
	public String getStream() 
	{
		return stream;
	}
	public void setStream(String stream) 
	{
		this.stream = stream;
	}
	@Override
	public String toString() 
	{
		return "ApplicantBean [applyId=" + applyId + ", fName=" + fName
				+ ", lName=" + lName + ", contactNo=" + contactNo + ", email="
				+ email + ", aggregate=" + aggregate + ", stream=" + stream
				+ "]";
	}


}
