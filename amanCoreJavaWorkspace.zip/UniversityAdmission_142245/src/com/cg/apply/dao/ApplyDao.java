package com.cg.apply.dao;

import java.util.ArrayList;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;





public interface ApplyDao 
{
	 public int addApplicantDetails(ApplicantBean ab)throws ApplicantException;
		public long generateApplyId()throws ApplicantException;
		public ArrayList<ApplicantBean> getApplicantDetails(long applyId)throws ApplicantException;
		public ArrayList<Long> getAllApplicantId()throws ApplicantException;
}
