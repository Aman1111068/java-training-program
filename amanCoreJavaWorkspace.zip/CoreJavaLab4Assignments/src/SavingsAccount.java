
public class SavingsAccount extends Account
{
private final int minimumBalance=500;

public SavingsAccount() 
{
	super();
	
}

public SavingsAccount(long accNum, double balance, Person accHolder)
{
	super(accNum, balance, accHolder);
	
}

public void withdraw(double amount)
{
	if((getAccBalance()-amount)>minimumBalance)
	{
		super.withdraw(amount);
	}
	else
	{
		System.out.println("Insufficient Balance");
	}
	
}
}
