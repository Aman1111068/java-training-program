
public class TestPersonAndAccount 
{

	public static void main(String[] args) 
	{
		Person p1=new Person("smith",20.0f);
		Person p2=new Person("kathy",30.0f);
		int accNum=(int)Math.round(Math.random()*100000);
		Account a1=new Account(accNum,2000.0,p1);
		Account a2=new Account(accNum,3000.0,p2);
        
		a2.withdraw(2000);
		a1.deposit(2000);
		
		System.out.println("Updated Balance is:"+a1.getBalance());
		System.out.println("Updated Balance is:"+a2.getBalance());
		
	}

}
