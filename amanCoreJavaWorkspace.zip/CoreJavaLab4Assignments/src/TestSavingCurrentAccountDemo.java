
public class TestSavingCurrentAccountDemo 
{
	public static void main(String[] args) 
	{
		Person p1=new Person("smith",20.0f);
		int accNum=(int)Math.round(Math.random()*100000);
		
		SavingsAccount s1=new SavingsAccount(accNum,60000,p1);
		s1.deposit(60000);
		s1.withdraw(40000);
		System.out.println(s1);
		System.out.println("Current Balance is :"+s1.getAccBalance());
	}
}

