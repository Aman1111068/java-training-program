
public class CurrentAccount extends Account 
{
	private double overDraftLmt = 40000;

	public CurrentAccount() 
	{
		super();
	}

	public CurrentAccount(long accNum, double balance, Person accHolder)
	{
		super(accNum, balance, accHolder);
	}
	@Override
	public void withdraw(double amount)
	{
		if(amount>overDraftLmt)
		{
			System.out.println("OverDraft Limit exceeds");
		}
		else
		{
			super.withdraw(amount);
		}
		
	}
	
}
