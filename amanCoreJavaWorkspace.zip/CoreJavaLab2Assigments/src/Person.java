
public class Person 
{
    private String firstName;
    private String lastName;
    private char gender;
    private int age;
    private float weight;
    
	
    public Person(String firstName, String lastName, char gender, int age,
			float weight) 
    {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}

	
	public void dispPersonDetails() 
	{
		System.out.println("Person Details:");
		System.out.println("-----------------------");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("Age:"+age);
		System.out.println("Weight:"+weight);
	}
    
	
}
