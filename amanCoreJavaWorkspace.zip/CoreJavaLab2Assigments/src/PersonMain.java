
public class PersonMain
{

	public static void main(String[] args) 
	{
		Person1 p1=new Person1();
		p1.setFirstName("AMAN");
		p1.setLastName("SHRIVASTAVA");
		p1.setGender('M');
		
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name:"+p1.getFirstName());
		System.out.println("Last Name:"+p1.getLastName());
		System.out.println("Gender:"+p1.getGender());
		
	

	}

}
