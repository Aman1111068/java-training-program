
public class Person2 
{
	private String firstName;
    private String lastName;
    private char gender;
    private String mobileNo;
    
    public Person2() 
    {
		
	}
    
    public String getFirstName() 
	{
		return firstName;
	}

    public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}

    public String getLastName() 
    {
		return lastName;
	}

    public void setLastName(String lastName) 
    {
		this.lastName = lastName;
	}

    public char getGender() 
    {
		return gender;
	}

    public void setGender(char gender) 
    {
		this.gender = gender;
	}
    
    public Person2(String mobileNo)
    {
    	this.mobileNo=mobileNo;
    }

	/*public Person2(String firstName, String lastName, char gender,
			String mobileNo) 
	{
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNo = mobileNo;
	}*/
    
	public void dispPersonInfo()
	{
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
        System.out.println("MOBILE NO:"+mobileNo);
	}

	
    
}
