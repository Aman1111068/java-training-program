
public class Person3 
{
	private String firstName;
    private String lastName;
    private Gender gender;
    private String mobileNo;
    
    public Person3() 
    {
		
	}
    
    public String getFirstName() 
	{
		return firstName;
	}

    public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
    
    public void setGender(Gender gender) 
	{
		this.gender = gender;
	}
    
    public Gender getGender(Gender gender ) 
   	{
   		return gender;
   	}

    public String getLastName() 
    {
		return lastName;
	}

    public void setLastName(String lastName) 
    {
		this.lastName = lastName;
	}

   
    
    public Person3(String mobileNo)
    {
    	this.mobileNo=mobileNo;
    }

	/*public Person2(String firstName, String lastName, char gender,
			String mobileNo) 
	{
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNo = mobileNo;
	}*/
    
	public void dispPersonInfo()
	{
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
        System.out.println("MOBILE NO:"+mobileNo);
	}

     
}
