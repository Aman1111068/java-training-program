
public class Person1 
{
	private String firstName;
    private String lastName;
    private char gender;
   
    public String getFirstName() 
	{
		return firstName;
	}

    public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}

    public String getLastName() {
		return lastName;
	}

    public void setLastName(String lastName) {
		this.lastName = lastName;
	}

    public char getGender() {
		return gender;
	}

    public void setGender(char gender) {
		this.gender = gender;
	}

}















/*
public class Person
{
    private String firstName;
    private String lastName;
    char gender;
    private int phoneNo;
    
    //2.3 Create a person class, Generate appropriate Getters and Setters
    //2.4 Modify lab 2.3 to accept phone no
    //setter functions
    public void setFirstName(String fName)
    {
        this.firstName = fName;
    }
    
    public void setLastName(String lName)
    {
        this.lastName = lName;
    }
    
    public void setGender(char g)
    {
        this.gender = g;
    }
    
    //getter functions
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public char getGender()
    {
        return gender;
    }
    
    //2.4 Modify lab 2.3 to accept phone no
    //default constructor Person
    public Person()
    {
        //super();
        firstName = "Unknown";
        lastName = "Unknown";
        gender = ' ';
        phoneNo = 0;
    }

    //parameterized constructor Person
    public Person(String firstName, String lastName, char gender, int phoneNo)
    {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.phoneNo = phoneNo;
    }

    //method to display person details
    public String displayPersonDetails()
    {
        return "First Name:"+firstName+"\nLast Name: "+lastName+"\nGender: "+gender+"\nPhone Number: "+phoneNo;
    }
    
    public void dispPerson()
    {
        String f = firstName;
        String l = lastName;
        char g = gender;
        int ph = phoneNo;
        System.out.println("\nPerson Details:Using dispPerson():");
        System.out.println("First Name: "+f);
        System.out.println("Last Name: "+l);
        System.out.println("Gender: "+g);
        System.out.println("Phone No: "+ph);
    }
}
*/
