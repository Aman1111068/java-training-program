
public class PositiveOrNegative 
{
    
    
    public static void main(String[] args)
    {
    	int number;
    	number=Integer.parseInt(args[0]);
    	if(number>0)
    	{
    		System.out.println("Number"+number+" is positive");
    	}
    	else
    	{
    		System.out.println("Number"+number+" is negative");
    	}
    }
}
