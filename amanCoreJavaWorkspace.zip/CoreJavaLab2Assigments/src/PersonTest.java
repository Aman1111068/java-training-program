
public class PersonTest 
{

	public static void main(String[] args) 
	{
		Person p1=new Person("AMAN","SHRIVASTAVA",'M',21,70.0f);
		p1.dispPersonDetails();

	}

}
