
public class PersonMain1 {

	public static void main(String[] args) 
	{
		//Person2 p1=new Person2();
		Person2 p1=new Person2("8109453231");
		p1.setFirstName("AMAN");
		p1.setLastName("SHRIVASTAVA");
		p1.setGender('M');
		
		p1.dispPersonInfo();
	}

}






















/*import java.util.Scanner;

public class PersonMain
{

    public static void main(String[] args)
    {
        //2.3 Create a person class, Generate appropriate Getters and Setters
        //2.4 Modify lab 2.3 to accept phone no
        
        
        Scanner sc = new Scanner(System.in);
        Person p1 = new Person();
        Person p2 = new Person();
        String fName, lName;
        char g;
        
        int ph;
        
        /*System.out.println("Enter First Name: ");
        fName = sc.next();
        p1.setFirstName(fName);
        System.out.println("Enter Last Name: ");
        lName = sc.next();
        p1.setLastName(lName);
        System.out.println("Enter Gender: ");
        g = sc.next().charAt(0);
        p1.setGender(g);
        
        System.out.println("Person Details:");
        System.out.println("___________________");
        System.out.println("First Name: "+p1.getFirstName());
        System.out.println("Last Name: "+p1.getLastName());
        System.out.println("Gender: "+p1.getGender());
        */
        
        //2.4 Modify lab 2.3 to accept phone no
       /* System.out.println("Enter First Name: ");
        fName = sc.next();
        System.out.println("Enter Last Name: ");
        lName = sc.next();
        System.out.println("Enter Gender: ");
        g = sc.next().charAt(0);
        System.out.println("Enter Phone Number: ");
        ph = sc.nextInt();
        p2 = new Person(fName,lName,g,ph);
        System.out.println("Person Details:\n________________\n"+p2.displayPersonDetails());
        
        p2.dispPerson();
    }

}*/
