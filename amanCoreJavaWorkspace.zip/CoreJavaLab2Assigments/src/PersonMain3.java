
public class PersonMain3 
{
	public static void main(String[] args) 
	{
		//Person2 p1=new Person2();
		Person3 p3=new Person3("8109453231");
		p3.setFirstName("AMAN");
		p3.setLastName("SHRIVASTAVA");
		p3.setGender(Gender.M);
		
		p3.dispPersonInfo();
	}

}
