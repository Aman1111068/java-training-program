
public class TestDateDemo 
{

	public static void main(String[] args) 
	{
	    Date amanDOJ=new Date(13, 12, 2017);
	    
	    System.out.println("AMAN DOJ IS:"+amanDOJ.dispDate());
	    
	    Date vaiDOJ=new Date(03, 04, 2013);
	    
	    System.out.println("VAISHALI DOJ IS:"+vaiDOJ.dispDate());
	    
	    Date unknownPerson=new Date();
	   
	    System.out.println("Unknown person DOJ IS:"+unknownPerson.dispDate());

	}

}
