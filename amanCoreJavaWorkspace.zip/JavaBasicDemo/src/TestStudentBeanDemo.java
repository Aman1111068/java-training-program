
public class TestStudentBeanDemo 
{

	public static void main(String[] args) 
	{
		Student s1=new Student();
		s1.setRollNo(111);
		s1.setStuName("aman");
		s1.setMark(45);
		
		System.out.println("ROLL NO:"+s1.getRollNo());
		System.out.println("STUDENT NAME:"+s1.getStuName());
		System.out.println("STUDENT MARKS:"+s1.getMark());
		System.out.println("********************************");
		
		Student s2=new Student();
		s2.setRollNo(222);
		s2.setStuName("vaishali");
		s2.setMark(80);
		
		System.out.println("ROLL NO:"+s2.getRollNo());
		System.out.println("STUDENT NAME:"+s2.getStuName());
		System.out.println("STUDENT MARKS:"+s2.getMark());
		System.out.println("********************************");
		
	}

}
