
public class TestEmployeeDemo 
{
	public static void main(String[] args) 
	{
	    Employee aman =new Employee(1001,"AMAN",5000.0f,'M');
	    
	    System.out.println("AMAN DETAILS IS:"+aman.dispEmp());
	    
        Employee vaishali=new Employee(1002,"VAISHALI",10000.0f,'F');
	    
	    System.out.println("VAISHALI DETAILS IS:"+vaishali.dispEmp());
	    
        Employee unknownPerson=new Employee();
	    
	    System.out.println("unknownPerson DETAILS IS:"+unknownPerson.dispEmp());
	}

}
