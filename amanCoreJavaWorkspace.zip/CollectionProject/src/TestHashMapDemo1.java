	import java.util.HashMap;
		import java.util.Iterator;
		import java.util.Map.Entry;
		import java.util.Set;

public class TestHashMapDemo1 {

	public static void main(String[] args) {
		

			    HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
			    mobileDirectory.put(8812121221l, "VaishaliS");
			    mobileDirectory.put(8812152651l, "AmanS");
			    mobileDirectory.put(8812655521l, "DivyaS");
			    mobileDirectory.put(8815523221l, "DivyanshS");
			    mobileDirectory.put(8812121221l, "VaishaliS");
			    
			   Set<Long> setIt= mobileDirectory.keySet();
			    Iterator<Long> mobIt=setIt.iterator();
			    while(mobIt.hasNext())
			   {
			    	 
			    	System.out.println(" Mobile:"+mobIt.next());
			    }

			}

		


	}


