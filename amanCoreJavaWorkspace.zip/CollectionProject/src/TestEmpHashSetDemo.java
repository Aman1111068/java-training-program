import java.util.HashSet;


public class TestEmpHashSetDemo 
{

	public static void main(String[] args) 							
	{
		HashSet<Emp> empSet=new HashSet<Emp>();
		Emp e1=new Emp(333,"Vaishali S",4000.0f);
		Emp e2=new Emp(111,"Aman S",2000.0f);
		Emp e3=new Emp(222,"Divya S",4000.0f);
		Emp e4=new Emp(444,"Divyansh S",5000.0f);
		Emp e5=new Emp(333,"Vaishali S",4000.0f);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		
	for(Emp tempE:empSet)
	{
		System.out.println(tempE);
	}

	}

}
