import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;


public class TestHashMapDemo2 
{

	public static void main(String[] args) 
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
	    mobileDirectory.put(8812121221l, "VaishaliS");
	    mobileDirectory.put(8812152651l, "AmanS");
	    mobileDirectory.put(8812655521l, "DivyaS");
	    mobileDirectory.put(8815523221l, "DivyanshS");
	    mobileDirectory.put(8812121221l, "VaishaliS");
	 Collection cal= mobileDirectory.values();
	    Iterator mobIt=cal.iterator();
	    while(mobIt.hasNext())
	   {
	    	String value=(String) mobIt.next();
	    	System.out.println(" Name:"+value);
	    }


	}

}
