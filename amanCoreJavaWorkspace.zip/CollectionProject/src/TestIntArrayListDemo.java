import java.util.ArrayList;
import java.util.Iterator;


public class TestIntArrayListDemo 
{

	public static void main(String[] args) 
	{
		//making ARRAYLIST generic so that it is type safe & allows only integer values
		ArrayList<Integer> intList=new ArrayList<Integer>();//dealing with objects(creating primitive to object)-Boxing
		Integer i1= new Integer(10);
		Integer i2= new Integer(2);
		Integer i3= new Integer(30);
		Integer i4= new Integer(4);
		Integer i5= new Integer(30);
		
		intList.add(i1);//adding objects into arrayList
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		System.out.println("*****WITHOUT ITERATOR****");
		System.out.println(intList);
		System.out.println("*****WITH ITERATOR****");
		Iterator<Integer> it=intList.iterator();//iterator is provided for retrieving object one by one
		while(it.hasNext())//going for next object
		{
			//System.out.println( ": "+ it.next()); fetching next objects
			int tempNum=it.next();//auto unboxing
			System.out.println( ": "+tempNum);
		}

	}

}
