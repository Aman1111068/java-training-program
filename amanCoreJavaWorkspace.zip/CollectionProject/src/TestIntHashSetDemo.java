import java.util.HashSet;


public class TestIntHashSetDemo 
{

	public static void main(String[] args) 
	{
	HashSet<Integer> intSet=new HashSet<Integer>();
	Integer i1= new Integer(10);//random and unique
	Integer i2= new Integer(2);
	Integer i3= new Integer(30);
	Integer i4= new Integer(4);
	Integer i5= new Integer(30);
	
	intSet.add(i1);//adding objects into arrayList
	intSet.add(i2);
	intSet.add(i3);
	intSet.add(i4);
	intSet.add(i5);
	System.out.println("*****WITHOUT ITERATOR****");
	System.out.println(intSet);

	}

}
