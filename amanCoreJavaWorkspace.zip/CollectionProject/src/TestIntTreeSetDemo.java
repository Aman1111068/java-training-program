
import java.util.TreeSet;


public class TestIntTreeSetDemo 
{

	public static void main(String[] args)
	{
		TreeSet<Integer> treeSet=new TreeSet<Integer>();
		Integer i1= new Integer(10);//sorted and unique
		Integer i2= new Integer(2);
		Integer i3= new Integer(30);
		Integer i4= new Integer(4);
		Integer i5= new Integer(30);
		
		treeSet.add(i1);//adding objects into arrayList
		treeSet.add(i2);
		treeSet.add(i3);
		treeSet.add(i4);
		treeSet.add(i5);
		System.out.println("*****WITHOUT ITERATOR****");
		System.out.println(treeSet);

		}

	}


