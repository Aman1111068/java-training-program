import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;





public class TestHashMapDemo
{

	public static void main(String[] args) 
	{
	    HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
	    mobileDirectory.put(8812121221l, "VaishaliS");
	    mobileDirectory.put(8812152651l, "AmanS");
	    mobileDirectory.put(8812655521l, "DivyaS");
	    mobileDirectory.put(8815523221l, "DivyanshS");
	    mobileDirectory.put(8812121221l, "VaishaliS");
	   Set<Entry<Long,String>> setIt= mobileDirectory.entrySet();
	    Iterator<Entry<Long,String>> mobIt=setIt.iterator();
	    while(mobIt.hasNext())
	   {
	    	Entry<Long,String> dirEntry=mobIt.next();
	    	System.out.println(" Mobile:"+dirEntry.getKey()+
	    			" Name:"+dirEntry.getValue());
	    }

	}

}
