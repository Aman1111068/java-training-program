
import java.util.*;


public class TestEmpTreeSetDemo 
{

	public static void main(String[] args) 
	{
		TreeSet<Emp> treeSet=new TreeSet<Emp>();
		Emp e1=new Emp(333,"Vaishali S",4000.0f);
		Emp e2=new Emp(111,"Aman S",2000.0f);
		Emp e3=new Emp(222,"Divya S",4000.0f);
		Emp e4=new Emp(444,"Divyansh S",5000.0f);
		Emp e5=new Emp(333,"Vaishali S",4000.0f);
		
		treeSet.add(e1);
		treeSet.add(e2);
	    treeSet.add(e3);
		treeSet.add(e4);
		treeSet.add(e5);
		
		
	for(Emp tempE:treeSet)
	{
		System.out.println(tempE);
	}

	}

}
