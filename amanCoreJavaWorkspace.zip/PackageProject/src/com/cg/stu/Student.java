package com.cg.stu;
import com.cg.bat.Batch;
public class Student 
{
	private int rollNo;
	private String studentName;
	private float marks;
	private Batch stuBatch;
	
	public Student() 
	{
		super();
		
	}
	
	public Student(int rollNo, String studentName, float marks, Batch stuBatch) {
		super();
		this.rollNo = rollNo;
		this.studentName = studentName;
		this.marks = marks;
		this.stuBatch = stuBatch;
	}

	public int getRollNo() 
	{
		return rollNo;
	}
	public void setRollNo(int rollNo) 
	{
		this.rollNo = rollNo;
	}
	public String getStudentName() 
	{
		return studentName;
	}
	public void setStudentName(String studentName)
	{
		this.studentName = studentName;
	}
	public float getMarks() 
	{
		return marks;
	}
	public void setMarks(float marks) 
	{
		this.marks = marks;
	}
	public Batch getStuBatch() 
	{
		return stuBatch;
	}
	public void setStuBatch(Batch stuBatch) 
	{
		this.stuBatch = stuBatch;
	}

	
	public String dispStuInfo() 
	{
		return "Student [rollNo=" + rollNo + 
				", studentName=" + studentName+ 
				", marks=" + marks + 
				", stuBatch=" + stuBatch.showBatchInfo() + "]";
	}
	

}
