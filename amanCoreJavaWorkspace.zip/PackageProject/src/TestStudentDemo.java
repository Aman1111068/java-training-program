import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TestStudentDemo 
{

	public static void main(String[] args) 
	{
		Batch javaBatch=new Batch("JEE_Propel_001",
				"8.30 TO 6.00","Anjulata Tembhare");
		Batch vnvBatch=new Batch("vnv_Pt_002",
				"9.00 TO 6.00","Shilpa Bhosale");
		Batch oraAppBatch=new Batch("OraApp_ABridge_003",
				"9.00 TO 6.00","Sachin Naradekar");
		Student student1=new Student(11,"AMAN",90,javaBatch);
		Student student2=new Student(22,"Ashu",56,javaBatch);
		Student student3=new Student(33,"Divya",70,vnvBatch);
		Student student4=new Student(44,"Divyansh",67,oraAppBatch);
		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());
		System.out.println(student4.dispStuInfo());
	}

}
