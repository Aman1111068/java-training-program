package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;
@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao
{
@PersistenceContext
EntityManager em;
	@Override
	public List<Integer> getAllEmployeeId() 
	{
		Query query1=em.createQuery("Select e.empId from EmployeeDetails e");
		
		return query1.getResultList();
	}

	@Override
	public List<EmployeeLeaveDetails> getLeaveDetails(int empId)
	{
		
		Query query=em.createQuery("FROM EmployeeLeaveDetails where empId=:eid");
		query.setParameter("eid", empId);
		return query.getResultList();
	
	}

	@Override
	public EmployeeDetails getEmployeeDetails(int empId) 
	{
		EmployeeDetails ed=em.find(EmployeeDetails.class, empId);
		return ed;
	}

}
