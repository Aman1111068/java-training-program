package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;

public interface IEmployeeDao 
{
	List<Integer> getAllEmployeeId();
	List<EmployeeLeaveDetails> getLeaveDetails(int empId);
	EmployeeDetails getEmployeeDetails(int empId);

}
