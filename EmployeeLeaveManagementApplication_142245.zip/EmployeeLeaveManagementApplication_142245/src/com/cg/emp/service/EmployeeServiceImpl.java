package com.cg.emp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;
@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao employeedao;

	@Override
	public List<Integer> getAllEmployeeId() 
	{
		
		return employeedao.getAllEmployeeId();
	}

	@Override
	public List<EmployeeLeaveDetails> getLeaveDetails(int empId) {
		
		return employeedao.getLeaveDetails(empId);
	}

	@Override
	public EmployeeDetails getEmployeeDetails(int empId) {
		
		return employeedao.getEmployeeDetails(empId);
	}
	
	@Override
	public boolean validateEmpId(int empId)
	{
		List<Integer> elist=employeedao.getAllEmployeeId();
		for(int i:elist)
		{
			if(i==empId)
			{
				return true;
			}
			
		}
		return false;
		
		
	}
	

}


	
