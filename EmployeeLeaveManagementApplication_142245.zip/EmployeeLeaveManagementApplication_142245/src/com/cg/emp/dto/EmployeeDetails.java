package com.cg.emp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	
	@Id
	@Column(name="empid")
	private int empId;
	@Column(name="ename")
	private String eName;
	@Column(name="address")
	private String address;
	@Column(name="leaves_avail")
	private int leavesAvail;
	public int getEmpId()
	{
		return empId;
	}
	public void setEmpId(int empId) 
	{
		this.empId = empId;
	}
	public String geteName() 
	{
		return eName;
	}
	public void seteName(String eName) 
	{
		this.eName = eName;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public int getLeavesAvail() 
	{
		return leavesAvail;
	}
	public void setLeavesAvail(int leavesAvail) 
	{
		this.leavesAvail = leavesAvail;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", eName=" + eName
				+ ", address=" + address + ", leavesAvail=" + leavesAvail + "]";
	}
}
