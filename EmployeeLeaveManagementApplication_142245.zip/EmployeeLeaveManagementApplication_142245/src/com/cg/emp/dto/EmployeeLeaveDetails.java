package com.cg.emp.dto;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails 
{
	@Id
	@Column(name="leave_id")
	private int leaveId;
	@Column(name="empid")
	private int empId;
	@Column(name="start_date")
	private String startDate;
	@Column(name="end_date")
	private String endDate;
	@Column(name="description")
	private String description;
	@Column(name="leaves_applied")
	private int leavesApplied;
	
	
	@Override
	public String toString() {
		return "EmployeeLeaveDetails [leaveId=" + leaveId + ", empId=" + empId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", description=" + description + ", leavesApplied="
				+ leavesApplied + "]";
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getLeavesApplied() {
		return leavesApplied;
	}
	public void setLeavesApplied(int leavesApplied) {
		this.leavesApplied = leavesApplied;
	}
	
	

}
