package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;
import com.cg.emp.service.IEmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	IEmployeeService employeeservice;
	
	
	@RequestMapping(value="show", method=RequestMethod.GET)
	public String getData()
	{
		return "Home";
	}
	
  /*	@RequestMapping(value="emphis", method=RequestMethod.GET)
	public String getValidEmpId(@RequestParam("id") int id)
	{
		List<Integer> elist=employeeservice.getAllEmployeeId();
		
		if(employeeservice.validateEmpId(id))
		{
			return "success";
		}
		return "fail";
	}*/

	  	/*@RequestMapping(value="emphis", method=RequestMethod.GET)
	  	public ModelAndView findHistory(@RequestParam("id") int id)
	  	{
	  		
	  		if(employeeservice.validateEmpId(id))
	  		{
	  			List<EmployeeLeaveDetails> elist=employeeservice.getLeaveDetails(id);
	  			EmployeeDetails ed=employeeservice.getEmployeeDetails(id);
	  			
	  			return new ModelAndView("ViewLeaveDetails","temp",elist);
	  		}
	  		return new ModelAndView("Home","message","This Employee ID does not exist");
	  	}*/
	
	@RequestMapping(value="emphis", method=RequestMethod.GET)
  	public ModelAndView findHistory(@RequestParam("id") int id)
  	{
  		ModelAndView mv=new ModelAndView();
  		if(employeeservice.validateEmpId(id))
  		{
  			List<EmployeeLeaveDetails> elist=employeeservice.getLeaveDetails(id);
  			EmployeeDetails ed=employeeservice.getEmployeeDetails(id);
  			
  			mv.setViewName("ViewLeaveDetails");
  			mv.addObject("temp", elist);
  			mv.addObject("temp1", ed);
  			return mv;
  		}
  		return new ModelAndView("Home","message","This Employee ID does not exist");
  	}

}
 