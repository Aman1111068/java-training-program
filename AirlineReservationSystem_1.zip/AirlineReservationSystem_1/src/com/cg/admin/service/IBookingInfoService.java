package com.cg.admin.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;

public interface IBookingInfoService 
{
	 List<BookingInformation> getAllBookings(int flightNo) throws AdminException;
	 int countBookingIds(int fno)throws AdminException;
}
