package com.cg.admin.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.admin.dao.BookingInfoDao;
import com.cg.admin.dao.BookingInfoDaoImpl;
import com.cg.admin.dto.BookingInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;

public class BookingInfoService implements IBookingInfoService {
BookingInfoDao bDao=new BookingInfoDaoImpl();
	

	@Override
	public int countBookingIds(int fno) throws AdminException 
	{
		
		return bDao.countBookingIds(fno);
	}


	@Override
	public List<BookingInformation> getAllBookings(int flightNo)
			throws AdminException 
	{
		
		return bDao.getAllBookings(flightNo);
	}



}
