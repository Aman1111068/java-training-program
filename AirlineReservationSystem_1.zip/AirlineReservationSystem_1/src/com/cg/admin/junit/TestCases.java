package com.cg.admin.junit;

public class TestCases 
{
	

}
