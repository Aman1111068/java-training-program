package com.cg.admin.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;



import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.util.DBUtil;




public class FlightInfoDaoImpl implements FlightInfoDao
{
	Connection conn;
	@Override
	public int insertFlightInformation(FlightInformation fi)
			throws AdminException 
	{
		int dataAdded;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.INSERT_FLIGHT_INFORMATION);
			pst.setInt(1,fi.getFlightNo());
			pst.setString(2, fi.getAirline());
			pst.setString(3, fi.getDeptCity());
			pst.setString(4, fi.getArrCity());
			pst.setDate(5, Date.valueOf(fi.getDeptDate()));
			pst.setDate(6, Date.valueOf(fi.getArrDate()));
			pst.setString(7, fi.getDeptTime());
			pst.setString(8, fi.getArrTime());
			pst.setInt(9,fi.getFirstSeats());
			pst.setDouble(10, fi.getFirstSeatsFare());
			pst.setInt(11, fi.getBussSeats());
			pst.setDouble(12, fi.getBussSeatsFare());
			pst.setInt(13, fi.getAvlFirstSeats());
			pst.setInt(14, fi.getAvlBussSeats());
			
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e) 
		{
			throw new AdminException("Problem in inserting Flight Details"+e.getMessage());
			
		} 
		
		
		
		return dataAdded;
	}

	
	

	

	@Override
	public FlightInformation getFlight(FlightInformation fi)
			throws AdminException 
	{
		
		return null;
	}

	@Override
	public ArrayList<FlightInformation> getFlightList(FlightInformation fi)
			throws AdminException 
	{
		
		return null;
	}






	@Override
	public int updateFlightDeptDate(LocalDate deptDate, int flightNo)
			throws AdminException 
	{
		int dataUpdated2 = 0;
		PreparedStatement pst;
		
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_DEPT_DATE);
			pst.setInt(2, flightNo);
			pst.setDate(1, Date.valueOf(deptDate));
			dataUpdated2=pst.executeUpdate();
		
		} 
		catch (Exception e) {
			
			throw new AdminException("Problem in Updating Flight Date Details"+e.getMessage());
		}
		return dataUpdated2;
		
	}






	@Override
	public int updateFlightArrDate(LocalDate arrDate, int flightNo)
			throws AdminException {
		int dataUpdated1 = 0;
		PreparedStatement pst;
		
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_ARR_DATE);
			pst.setInt(2, flightNo);
			pst.setDate(1, Date.valueOf(arrDate));
			dataUpdated1=pst.executeUpdate();
			
		} 
		catch (Exception e) 
		{
			
			throw new AdminException("Problem in Updating Flight Date Details"+e.getMessage());
		}
		return dataUpdated1;
		
	}






	@Override
	public int updateFirstFare(double ffare, int flightNo)
			throws AdminException 
	{
		int fareUpdated1 = 0;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_FIRST_FARES);
			pst.setDouble(1, ffare);
			pst.setInt(2, flightNo);
			fareUpdated1 = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Updating Flight Fare Details"+e.getMessage());
		}
		return fareUpdated1;
		
	}






	@Override
	public int updateBussFare(double bfare, int flightNo) throws AdminException 
	{
		int fareUpdated2 = 0;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_BUSS_FARES);
			pst.setDouble(1, bfare);
			pst.setInt(2, flightNo);
			fareUpdated2 = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Updating Flight Date Details"+e.getMessage());
		}
		return fareUpdated2;
	}






	@Override
	public int updateFlightArrTime(String atime, int flightNo)
			throws AdminException 
	{
		 String UPDATE_ARR_TIME="UPDATE flightInformation set arrivalTime=? WHERE flightNo=?";
	        
	        int dataUpdated1=0;
	        try
	        {
	            conn=DBUtil.getCon();
	            PreparedStatement pst= conn.prepareStatement(UPDATE_ARR_TIME);
	            pst.setString(1,atime);
	            pst.setInt(2, flightNo);
	            
	            dataUpdated1 = pst.executeUpdate();
	        }
	        
	        catch (Exception e) 
	        {
	            throw new AdminException("Problem in updating Flight Date Details"+e.getMessage());
	            
	        } 
	        
	        return dataUpdated1;
		
	}






	@Override
	public int updateFlightDeptTime(String dtime, int flightNo)
			throws AdminException 
	{
		String UPDATE_DEPT_TIME="UPDATE flightInformation set departureTime=? WHERE flightNo=?";
        int dataUpdated2=0;
        
        try
        {
            conn=DBUtil.getCon();
            PreparedStatement pst= conn.prepareStatement(UPDATE_DEPT_TIME);
            
            pst.setString(1,dtime);
            pst.setInt(2, flightNo);
            
            dataUpdated2 = pst.executeUpdate();
        }
        
        catch (Exception e) 
        {
            throw new AdminException("Problem in updating Flight Date Details"+e.getMessage());
            
        } 
        
        return dataUpdated2;
		
	}






	@Override
	public FlightInformation getFlightData(String aCity, LocalDate aDate)
			throws AdminException 
	{
		FlightInformation fi = null;
		try 
		{
			conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_FLIGHT_PAR_DAY_PAR_CITY);
			pst.setString(1, aCity);
			pst.setDate(2, Date.valueOf(aDate));
			ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
				fi = new FlightInformation();
				fi.setFlightNo(rs.getInt("FlightNo"));
				fi.setAirline(rs.getString("AirLine"));
				fi.setDeptCity(rs.getString("Source"));
				fi.setArrCity(rs.getString("Destination"));
				fi.setDeptDate(rs.getDate("DepartureDate").toLocalDate());
				fi.setArrDate(rs.getDate("ArrivalDate").toLocalDate());
				fi.setDeptTime(rs.getString("DepartureTime"));
				fi.setArrTime(rs.getString("ArrivalTime"));
				fi.setFirstSeats(rs.getInt("FirstSeats"));
				fi.setFirstSeatsFare(rs.getDouble("FirstSeatsFare"));
				fi.setBussSeats(rs.getInt("BussSeats"));
				fi.setBussSeatsFare(rs.getDouble("BussSeatsFare"));
				fi.setAvlFirstSeats(rs.getInt("FirstSeatsAvail"));
				fi.setAvlBussSeats(rs.getInt("BussSeatsAvail"));
			}
			else
			{
				throw new AdminException("Flight Details Not Found");
			}
		} 
		catch (Exception e) 
        {
            throw new AdminException("Problem in fetching Flight Details"+e.getMessage());
            
        } 
		return fi;
		
	}






	@Override
	public int updateFlightInformation(String arrCity, int flightNo)
			throws AdminException 
	{
		 int dataUpdated=0;
			try
			{
				conn=DBUtil.getCon(); 
				PreparedStatement pst=conn.prepareStatement(QueryMapper.UPDATE_ARR_CITY);
				 pst.setString(1,arrCity);
				 pst.setInt(2, flightNo);
				  
				 dataUpdated=pst.executeUpdate();
			}
				 catch(Exception e)
					{
				 	
					 throw new AdminException("Problem in Updating Flight Details"+e.getMessage());	
					}
			return dataUpdated;
		
	}






	@Override
	public int updateDeptFlightInfo(String deptCity, int flightNo)
			throws AdminException 
	{
		int dataUpdated=0;
		try
		{
			conn=DBUtil.getCon(); 
			PreparedStatement pst=conn.prepareStatement(QueryMapper.UPDATE_DEPT_CITY);
			 pst.setString(1,deptCity);
			 pst.setInt(2, flightNo);
			  
			 dataUpdated=pst.executeUpdate();
		}
			 catch(Exception e)
				{
			 	
				 throw new AdminException("Problem in Updating Flight Details"+e.getMessage());	
				}
		return dataUpdated;
		
	}






	@Override
	public int deleteFlightInformation(int flightNo) throws AdminException 
	{
		int dataDeleted=0;
		try
		{
			conn=DBUtil.getCon(); 
			PreparedStatement pst=conn.prepareStatement(QueryMapper.DELETE_FLIGHT_INFO);
			 
			 pst.setInt(1, flightNo);
			  
			 dataDeleted=pst.executeUpdate();
		}
			 catch(Exception e)
				{
			 	
				 throw new AdminException("Problem in Deleting Flight Details"+e.getMessage());	
				}
		return dataDeleted;
	}

}
