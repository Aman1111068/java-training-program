package com.cg.admin.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;

public interface BookingInfoDao 
{

	 int countBookingIds(int fno)throws AdminException;
	 List<BookingInformation> getAllBookings(int flightNo) throws AdminException;
}
