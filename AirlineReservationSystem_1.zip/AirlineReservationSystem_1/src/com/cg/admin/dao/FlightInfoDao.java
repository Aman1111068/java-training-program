package com.cg.admin.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;



public interface FlightInfoDao 
{
   int insertFlightInformation(FlightInformation fi)throws AdminException;
   FlightInformation getFlight(FlightInformation fi)throws AdminException;
   ArrayList<FlightInformation> getFlightList(FlightInformation fi)throws AdminException;
   
   int updateFlightDeptDate(LocalDate deptDate, int flightNo)throws AdminException;
	int updateFlightArrDate(LocalDate arrDate, int flightNo)throws AdminException;
	
	int updateFirstFare(double ffare, int flightNo)throws AdminException;
	int updateBussFare(double bfare, int flightNo)throws AdminException;
	
	int updateFlightArrTime(String atime,int flightNo)throws AdminException;
	int updateFlightDeptTime(String dtime,int flightNo)throws AdminException;
	
	FlightInformation getFlightData(String aCity, LocalDate aDate)throws AdminException;
	
	int updateFlightInformation(String arrCity,int flightNo)throws AdminException;
    int updateDeptFlightInfo(String deptCity,int flightNo)throws AdminException;
    int deleteFlightInformation(int flightNo) throws AdminException;
	
}
