package com.cg.admin.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;
import com.cg.admin.util.DBUtil;

public class BookingInfoDaoImpl implements BookingInfoDao 
{
	Connection conn;
	

	@Override
	public int countBookingIds(int fno) throws AdminException 
	{
		int count=0;
		PreparedStatement pst;
		ResultSet rs=null;
		try {
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.BOOKINGS_FOR_SPECIFIC_FLIGHT);
			pst.setInt(1, fno);
			rs=pst.executeQuery();
			rs.next();
			count=rs.getInt("No_Of_Bookings");
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in counting booking id"+e.getMessage());
		} 
		return count;
	}

	@Override
	public List<BookingInformation> getAllBookings(int flightNo)
			throws AdminException 
	{

		List<BookingInformation> bookList=new ArrayList<BookingInformation>();
		try 
		{
			conn=DBUtil.getCon();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.SELECT_BOOKING_INFO);
			pst.setInt(1, flightNo);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				BookingInformation bi=new BookingInformation();
				
				bi.setBookingId(rs.getInt("BookingId"));
				bi.setCustEmail(rs.getString("CustEmail"));
				bi.setNoOfPassengers(rs.getInt("NoOfPassengers"));
				bi.setClassType(rs.getString("ClassType"));
				bi.setTotalFare(rs.getDouble("TotalFare"));
				bi.setSeatNumber(rs.getString("SeatNumber"));
				bi.setCreditCardInfo(rs.getString("creditCardInfo"));
				bi.setSrcCity(rs.getString("SrcCity"));
				bi.setDestCity(rs.getString("DestCity"));
				bi.setFlightNo(rs.getInt("FlightNo"));
				bookList.add(bi);
				
			}
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Fetching Booking list "+e.getMessage());
		}
		
		return bookList;
		
	}
	
	
		
	}


