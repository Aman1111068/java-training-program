package com.cg.admin.dto;

public class Location 
{
	private int locationId;
	private String city;
	private String state;
	private int zipcode;
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Location(int locationId, String city, String state, int zipcode) {
		super();
		this.locationId = locationId;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", city=" + city
				+ ", state=" + state + ", zipcode=" + zipcode + "]";
	}
	

}
